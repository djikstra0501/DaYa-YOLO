# ADD THIS CODE TO conv.py OR block.py UNDER FOLDER nn/modules

# DaYa-YOLO

class SpectralFeatureEncoder(nn.Module):
    """
    Learnable Spectral Encoder for Rice Pest Detection (DaYa-YOLO).

    Modes:
        XYZ - CIE XYZ color space, full matrix initialization.
        LAB - True CIE LAB conversion (sRGB linearized, D65 white point),
              with 3 learnable scale parameters acting as automatic channel
              importance weights (equivalent to sliding L*, a*, b* sliders
              to find the best pest-visible combination).

    YAML usage:
        - [0, 1, SpectralFeatureEncoder, [3, "LAB"]]
        - [0, 1, SpectralFeatureEncoder, [3, "XYZ"]]
    """

    def __init__(self, c1=3, c2=3, mode="XYZ"):
        super().__init__()
        self.mode = mode.upper()
        assert self.mode in ("XYZ", "LAB"), \
            f"SpectralFeatureEncoder: mode must be 'XYZ' or 'LAB', got '{mode}'"

        if self.mode == "LAB":
            # ----------------------------------------------------------------
            # PART 1: Fixed RGB -> XYZ conversion (frozen, no gradients)
            # The network cannot change this — it is physics.
            # ----------------------------------------------------------------
            self.xyz_conv = nn.Conv2d(3, 3, kernel_size=1, stride=1, padding=0, bias=False)
            with torch.no_grad():
                self.xyz_conv.weight.copy_(torch.tensor([
                    [0.4124, 0.3576, 0.1805],  # -> X
                    [0.2126, 0.7152, 0.0722],  # -> Y (Luminance)
                    [0.0193, 0.1192, 0.9505],  # -> Z
                ]).view(3, 3, 1, 1))
            for p in self.xyz_conv.parameters():
                p.requires_grad = False  # frozen forever

            # D65 standard illuminant white point for normalization
            self.register_buffer("d65", torch.tensor(
                [0.95047, 1.00000, 1.08883]
            ).view(1, 3, 1, 1))

            # ----------------------------------------------------------------
            # PART 2: Learnable LAB channel scales (the "sliders")
            # Initialized at 1.0 = neutral (no scaling), but can be adjusted by the network during training.
            # During training, gradient descent finds the optimal scale for
            # each channel:
            #   lab_scale[0] -> how much L* (lightness) matters
            #   lab_scale[1] -> how much a* (green<->red) matters  <- likely dominant for pests
            #   lab_scale[2] -> how much b* (blue<->yellow) matters
            # This is like automated by the loss function.
            # ----------------------------------------------------------------
            self.lab_scale = nn.Parameter(torch.ones(1, 3, 1, 1))

            # ----------------------------------------------------------------
            # PART 3: Learnable 1x1 conv encoder
            # Takes the scaled LAB features and produces output feature channels
            # for the downstream backbone. Initialized as identity so training
            # starts from a neutral state.
            # ----------------------------------------------------------------
            self.encoder = nn.Conv2d(3, c2, kernel_size=1, stride=1, padding=0, bias=False)
            nn.init.eye_(self.encoder.weight.view(c2, 3))

        else:  # XYZ with strict frozen conversion, same logic as LAB
            # ----------------------------------------------------------------
            # PART 1: Fixed sRGB -> XYZ conversion (frozen, no gradients)
            # Includes gamma linearization, same as LAB pipeline
            # but stops before the cube root nonlinearity
            # ----------------------------------------------------------------
            self.xyz_conv = nn.Conv2d(3, 3, kernel_size=1, stride=1, padding=0, bias=False)
            with torch.no_grad():
                self.xyz_conv.weight.copy_(torch.tensor([
                    [0.4124, 0.3576, 0.1805],  # X
                    [0.2126, 0.7152, 0.0722],  # Y (Luminance)
                    [0.0193, 0.1192, 0.9505],  # Z
                ]).view(3, 3, 1, 1))
            for p in self.xyz_conv.parameters():
                p.requires_grad = False  # frozen forever, same as LAB

            # Normalize output to roughly [-1, 1] for training stability
            # XYZ values after D65 normalization are in [0, ~1.08]
            # divide by 1.0 keeps scale, just making it explicit
            self.register_buffer("xyz_scale", torch.tensor(
                [1.0 / 0.95047, 1.0 / 1.00000, 1.0 / 1.08883]
            ).view(1, 3, 1, 1))

            # ----------------------------------------------------------------
            # PART 2: Learnable XYZ channel scales (same as lab_scale)
            # xyz_scale[0] -> how much X matters
            # xyz_scale[1] -> how much Y (luminance) matters
            # xyz_scale[2] -> how much Z matters
            # ----------------------------------------------------------------
            self.xyz_scale = nn.Parameter(torch.ones(1, 3, 1, 1))

            # ----------------------------------------------------------------
            # PART 3: Learnable encoder, same as LAB
            # ----------------------------------------------------------------
            self.encoder = nn.Conv2d(3, c2, kernel_size=1, stride=1, padding=0, bias=False)
            nn.init.eye_(self.encoder.weight.view(c2, 3))
    
    def _srgb_to_xyz(self, x):
        """
        Mathematically correct sRGB -> CIE XYZ conversion.
        Same gamma linearization as LAB pipeline,
        stops before cube root nonlinearity.
        """
        # Step 0: Clamp and remove sRGB gamma
        x = x.clamp(0.0, 1.0)
        x = torch.where(
            x <= 0.04045,
            x / 12.92,
            ((x + 0.055) / 1.055).pow(2.4).clamp(min=0.0)
        )

        # Step 1: Linear RGB -> XYZ (frozen conv)
        xyz = self.xyz_conv(x).clamp(min=0.0)

        # Step 2: Normalize by D65 white point (same as LAB)
        xyz = xyz * self.xyz_scale

        return xyz

    def _rgb_to_lab(self, x):
        """
        Mathematically correct sRGB -> CIE LAB conversion.
        Identical pipeline to cv2.COLOR_BGR2Lab on float32 input.
        No learnable parameters here pure fixed math.
        """
        # Step 0: Clamp input to valid sRGB range before gamma removal and Remove sRGB gamma safely
        x = x.clamp(0.0, 1.0)
        x = torch.where(
            x <= 0.04045,
            x / 12.92,
            ((x + 0.055) / 1.055).pow(2.4).clamp(min=0.0)
        )

        # Step 1: Linear RGB -> XYZ
        xyz = self.xyz_conv(x).clamp(min=1e-8)  # never zero, protects pow(1/3)

        # Step 2: Normalize by D65
        xyz = xyz / self.d65

        # Step 3: Cube root with safe clamping to avoid zero/negative issues
        # clamp before pow so we never take root of zero or negative
        safe_xyz = xyz.clamp(min=0.008857)  # just above the threshold
        xyz = torch.where(
            xyz > 0.008856,
            safe_xyz.pow(1.0 / 3.0),
            7.787 * xyz + 16.0 / 116.0
        )

        # Step 4: L*, a*, b*
        L = (116.0 * xyz[:, 1:2] - 16.0) / 100.0
        a = (500.0 * (xyz[:, 0:1] - xyz[:, 1:2])) / 128.0
        b = (200.0 * (xyz[:, 1:2] - xyz[:, 2:3])) / 128.0

        return torch.cat([L, a, b], dim=1)

    def forward(self, x):
        if self.mode == "LAB":
            # Fixed math: RGB -> true LAB (no gradients flow here)
            x = self._rgb_to_lab(x)

            # Learnable sliders: scale each LAB channel is learn by network independently
            x = x * self.lab_scale.clamp(min=0.01)  # prevent negative scaling

            # Learnable encoder: produce output features from scaled LAB
            return self.encoder(x)

        else:  # XYZ with same logic as LAB but no cube root nonlinearity
            x = self._srgb_to_xyz(x)
            x = x * self.xyz_scale.clamp(min=0.01)
            return self.encoder(x)
        
# YOLO-PEST
# Source: "YOLO-PEST: a novel rice pest detection approach based on YOLOv5s"
#          Qiang et al., Plant Methods 2025  (Open Access, CC BY-NC-ND 4.0)
#          https://doi.org/10.1186/s13007-025-01438-w
#
# Two modules:
#   CoTAttention   — Contextual Transformer Attention (Li et al., TPAMI 2022)
#                    Placed BEFORE the SPPF layer in the backbone.
#   ConvNeXtBlock  — ConvNeXt-style block (Liu et al., CVPR 2022)
#                    Replaces C3 blocks in the neck for small-object fusion.


class CoTAttention(nn.Module):
    """
    Contextual Transformer (CoT) Attention — TPAMI 2022.
    Used in YOLO-PEST backbone, inserted before the SPPF layer.

    Fuses static context (local k×k group-conv on keys) with dynamic
    context (self-attention between queries and contextual keys) then
    outputs K1 + K2  (Eq. 1–3 in the paper).

    Args:
        dim       : input/output channels (unchanged)
        kernel_size: group-conv kernel for local context. Paper uses 3.
    """

    def __init__(self, dim: int, kernel_size: int = 3):
        super().__init__()
        self.dim = dim
        self.kernel_size = kernel_size

        # ── Static context: k×k group conv to get K1 ──────────────────────
        # groups=dim → depthwise; captures local spatial context per channel
        self.key_embed = nn.Sequential(
            nn.Conv2d(dim, dim,
                      kernel_size=kernel_size,
                      padding=kernel_size // 2,
                      groups=dim,
                      bias=False),
            nn.BatchNorm2d(dim),
            nn.ReLU(inplace=True),
        )

        # ── Value projection: 1×1 halves channels for efficiency ──────────
        self.value_embed = nn.Sequential(
            nn.Conv2d(dim, dim // 2, kernel_size=1, bias=False),
            nn.BatchNorm2d(dim // 2),
        )

        # ── Attention matrix A: two successive 1×1 convs on [K1, Q] ───────
        # Input = concat(K1, Q) → 2*dim channels
        # Paper Eq.1:  A = [K1, Q] · Wθ · Wδ
        factor = 4
        self.attn_embed = nn.Sequential(
            nn.Conv2d(2 * dim, 2 * dim // factor, kernel_size=1, bias=False),
            nn.BatchNorm2d(2 * dim // factor),
            nn.ReLU(inplace=True),
            nn.Conv2d(2 * dim // factor, kernel_size * kernel_size * (dim // 2),
                      kernel_size=1),
        )

        self.unfold = nn.Unfold(kernel_size=kernel_size,
                                padding=kernel_size // 2,
                                stride=1)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, C, H, W)
        B, C, H, W = x.shape

        # K1: static contextual key  (B, C, H, W)
        k1 = self.key_embed(x)

        # V: value  (B, C//2, H, W)
        v = self.value_embed(x).view(B, C // 2, -1)   # (B, C//2, H*W)

        # Attention matrix from [K1, Q=x]  (Q = original input)
        # (B, 2C, H, W) → conv stack → (B, k*k*C//2, H, W)
        y = torch.cat([k1, x], dim=1)
        attn = self.attn_embed(y)                      # (B, k²·C//2, H, W)

        # Unfold V into local k×k patches
        # unfold(v_spatial) → (B, C//2 * k², H*W)
        v_unf = self.unfold(
            self.value_embed(x)                        # reuse value spatial map
        )                                              # (B, C//2·k², H*W)

        # Reshape attn → (B, C//2, k², H*W) then softmax over k² dim
        k = self.kernel_size
        attn = attn.view(B, C // 2, k * k, H * W)
        attn = self.softmax(attn)                      # (B, C//2, k², H*W)

        # Reshape v_unf → (B, C//2, k², H*W)
        v_unf = v_unf.view(B, C // 2, k * k, H * W)

        # K2 = V · A  (Eq. 2): weighted sum over k² neighbourhood
        # (B, C//2, k², H*W) * (B, C//2, k², H*W) → sum over k² → (B, C//2, H*W)
        k2 = (attn * v_unf).sum(dim=2)                # (B, C//2, H*W)
        k2 = k2.view(B, C // 2, H, W)

        # Output = K1 + K2  (Eq. 3) — broadcast-add on C//2 channels,
        # then concat with the other C//2 half of K1 to keep full dim
        # Implementation note: original paper sums K1[:, :C//2] + K2 and
        # keeps K1[:, C//2:] unchanged, then concatenates.
        out = torch.cat([k1[:, :C // 2] + k2, k1[:, C // 2:]], dim=1)
        return out


class ConvNeXtBlock(nn.Module):
    """
    ConvNeXt-style block — used in YOLO-PEST neck to replace C3.

    Architecture per paper (Fig. 7 / 8):
        DWConv 7×7  →  LayerNorm  →  1×1 (expand ×4)  →  GELU  →  1×1 (project)
        + residual connection

    This is the inverted-bottleneck design from Liu et al., CVPR 2022,
    adapted as a drop-in C3 replacement in the YOLOv5s/YOLOv11 neck.

    Args:
        c1  : input channels
        c2  : output channels
        n   : number of stacked blocks  (handled by repeat_modules)
        e   : unused expansion placeholder (kept for YAML compat with C3)
    """

    def __init__(
        self,
        c1: int,
        c2: int,
        n: int = 1,
        shortcut: bool = True,
        g: int = 1,       # unused, YAML compat
        e: float = 0.5,   # unused, YAML compat
    ):
        super().__init__()

        # Optional channel projection when c1 != c2
        self.proj = (
            nn.Conv2d(c1, c2, kernel_size=1, bias=False)
            if c1 != c2 else nn.Identity()
        )

        # Stack of n ConvNeXt micro-blocks
        self.blocks = nn.Sequential(*[
            _ConvNeXtMicro(c2) for _ in range(n)
        ])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.blocks(self.proj(x))


class _ConvNeXtMicro(nn.Module):
    """Single ConvNeXt inverted-bottleneck micro-block."""

    def __init__(self, dim: int, expansion: int = 4):
        super().__init__()
        mid = dim * expansion
        self.block = nn.Sequential(
            # Depthwise 7×7 — extracts spatial context per channel
            nn.Conv2d(dim, dim, kernel_size=7, padding=3, groups=dim, bias=False),
            # LayerNorm applied channel-wise (permute trick for NCHW)
            _LayerNormNCHW(dim),
            # Pointwise expand
            nn.Conv2d(dim, mid, kernel_size=1, bias=False),
            nn.GELU(),
            # Pointwise project back
            nn.Conv2d(mid, dim, kernel_size=1, bias=False),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.block(x)   # residual


class _LayerNormNCHW(nn.Module):
    """LayerNorm for NCHW tensors (normalises over the channel dim)."""

    def __init__(self, num_channels: int, eps: float = 1e-6):
        super().__init__()
        self.norm = nn.LayerNorm(num_channels, eps=eps)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # (B, C, H, W) → (B, H, W, C) → norm → (B, C, H, W)
        return self.norm(x.permute(0, 2, 3, 1)).permute(0, 3, 1, 2)

# YOLO-DP
# Source: "YOLO-DP: A detection model of fifteen common rice diseases and pests"
# https://doi.org/10.1038/s41598-025-19310-1 (Nature Scientific Reports, Open Access, CC BY 4.0)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class ConvBNAct(nn.Module):
    """Conv + BN + activation (SiLU default)."""
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        if p is None:
            p = k // 2
        self.conv = nn.Conv2d(c1, c2, k, s, p, groups=g, bias=False)
        self.bn   = nn.BatchNorm2d(c2)
        self.act  = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


# ---------------------------------------------------------------------------
# TripletAttention  (backbone attention after SPPF)
# ---------------------------------------------------------------------------

class ZPool(nn.Module):
    """Concatenate max and avg along channel dim → 2-channel spatial descriptor."""
    def forward(self, x):
        return torch.cat([x.max(dim=1, keepdim=True).values,
                          x.mean(dim=1, keepdim=True)], dim=1)


class AttentionGate(nn.Module):
    def __init__(self):
        super().__init__()
        self.compress = ZPool()
        self.conv     = ConvBNAct(2, 1, k=7, act=nn.Sigmoid())

    def forward(self, x):
        return x * self.conv(self.compress(x))


class TripletAttention(nn.Module):
    """
    Triplet Attention — channel-preserving, no args needed from YAML.
    Applies three attention branches: C×H, C×W, H×W.
    """
    def __init__(self, c1):  # c1 unused (channel-preserving), kept for parse_model compat
        super().__init__()
        self.cw = AttentionGate()   # permute → attend C×W
        self.hc = AttentionGate()   # permute → attend H×C
        self.hw = AttentionGate()   # attend H×W directly

    def forward(self, x):
        # Branch 1: rotate to (B, W, H, C) → treat W as "channel"
        x_cw = self.cw(x.permute(0, 3, 2, 1)).permute(0, 3, 2, 1)
        # Branch 2: rotate to (B, H, C, W) → treat H as "channel"
        x_hc = self.hc(x.permute(0, 2, 1, 3)).permute(0, 2, 1, 3)
        # Branch 3: standard spatial attention (H×W)
        x_hw = self.hw(x)
        return (x_cw + x_hc + x_hw) / 3.0


# ---------------------------------------------------------------------------
# SimFusion_4in  — Low-GD Feature Alignment Module (4 inputs)
# ---------------------------------------------------------------------------

class SimFusion_4in(nn.Module):
    """
    Align 4 backbone feature maps to the smallest spatial size via adaptive
    avg-pool, then concatenate along channel dim.
    Input: list of 4 tensors [P2, P3, P4, P5]
    Output: single tensor (B, sum_C, H_min, W_min)
    """
    def forward(self, xs):
        target_h = min(x.shape[2] for x in xs)
        target_w = min(x.shape[3] for x in xs)
        aligned = [F.adaptive_avg_pool2d(x, (target_h, target_w)) for x in xs]
        return torch.cat(aligned, dim=1)


# ---------------------------------------------------------------------------
# IFM  — Information Fusion Module (Low-GD global token generator)
# ---------------------------------------------------------------------------

class IFM(nn.Module):
    """
    Produces low-level global tokens from the concatenated SimFusion_4in output.

    Args:
        c1          : input channels  (= sum of 4 backbone stage channels after scaling)
        trans_channels: list [ch0, ch1] — sizes of the two token groups to split into.
                        e.g. [64, 32] → output has 96 channels split as [64, 32].

    YAML usage:  [-1, 1, IFM, [[64, 32]]]
    """
    def __init__(self, c1, trans_channels):
        super().__init__()
        embed_dim = sum(trans_channels)
        self.conv1   = ConvBNAct(c1, embed_dim, k=1)
        self.dw_conv = ConvBNAct(embed_dim, embed_dim, k=3, g=embed_dim)
        self.conv2   = ConvBNAct(embed_dim, embed_dim, k=1)
        self.trans_channels = trans_channels

    def forward(self, x):
        x = self.conv1(x)
        x = self.dw_conv(x)
        x = self.conv2(x)
        return x.split(self.trans_channels, dim=1)   # tuple of tensors


# ---------------------------------------------------------------------------
# SimFusion_3in  — Low-GD Feature Alignment Module (3 inputs)
# ---------------------------------------------------------------------------

class SimFusion_3in(nn.Module):
    """
    Align 3 feature maps to the largest spatial size, concatenate, then fuse
    to `out_channels` with a 1×1 conv.

    Args:
        in_channel_list : list of 2 extra channel counts (3rd = from previous layer, inferred)
        out_channels    : output channel count

    YAML usage:  [[4, 6, -1], 1, SimFusion_3in, [512]]
    The three input feature maps come from YAML `from` indices.
    SimFusion_3in only needs out_channels; total_in is computed in forward from actual inputs.
    """
    def __init__(self, total_in, out_channels):
        super().__init__()
        self.out_channels = out_channels
        self.fuse = ConvBNAct(total_in, out_channels, k=1)

    def forward(self, xs):
        target_h = max(x.shape[2] for x in xs)
        target_w = max(x.shape[3] for x in xs)
        aligned = [
            F.interpolate(x, size=(target_h, target_w), mode='bilinear', align_corners=False)
            if (x.shape[2] != target_h or x.shape[3] != target_w) else x
            for x in xs
        ]
        return self.fuse(torch.cat(aligned, dim=1))


# ---------------------------------------------------------------------------
# InjectionMultiSum_Auto_pool  — injects global token into local feature
# ---------------------------------------------------------------------------

class InjectionMultiSum_Auto_pool(nn.Module):
    """
    Inject a global token (split from IFM/TopBasicLayer output) into a local
    feature map via element-wise addition after learned projection + pooling.

    Args:
        c1          : local feature channels (= output channels)
        c2          : output channels (== c1 for Gold-YOLO usage)
        trans_channels: list [ch0, ch1] — sizes of the two token groups
        token_idx   : which token group to use (0 or 1)

    YAML usage:  [[-1, 12], 1, InjectionMultiSum_Auto_pool, [512, [64, 32], 0]]
    """
    def __init__(self, c1, c2, trans_channels, token_idx):
        super().__init__()
        self.token_idx   = token_idx
        token_c          = trans_channels[token_idx]
        self.local_proj  = ConvBNAct(c1, c2, k=1)
        self.token_proj  = ConvBNAct(token_c, c2, k=1)
        self.out_proj    = ConvBNAct(c2, c2, k=1)

    def forward(self, xs):
        # xs[0] = local feature map, xs[1] = tuple of tokens from IFM
        local, tokens = xs
        token = tokens[self.token_idx]              # (B, token_c, Ht, Wt)
        # Pool token to match local spatial size
        token_up = F.adaptive_avg_pool2d(token, (local.shape[2], local.shape[3]))
        out = self.local_proj(local) + self.token_proj(token_up)
        return self.out_proj(out)


# ---------------------------------------------------------------------------
# PyramidPoolAgg  — High-GD Feature Alignment Module
# ---------------------------------------------------------------------------

class PyramidPoolAgg(nn.Module):
    """
    Aggregate features from multiple scales by adaptive pooling to a common
    spatial size, then concatenate.

    Args:
        out_channels: total output channels (for the projection conv)
        stride      : downsample stride used to compute target spatial size

    YAML usage:  [[20, 16, 10], 1, PyramidPoolAgg, [352, 2]]
    """
    def __init__(self, total_in, out_channels, stride=2):
        super().__init__()
        self.stride = stride
        self.proj   = ConvBNAct(total_in, out_channels, k=1)

    def forward(self, xs):
        h = min(x.shape[2] for x in xs) // self.stride
        w = min(x.shape[3] for x in xs) // self.stride
        pooled = [F.adaptive_avg_pool2d(x, (h, w)) for x in xs]
        return self.proj(torch.cat(pooled, dim=1))


# ---------------------------------------------------------------------------
# TopBasicLayer  — High-GD transformer-style IFM
# ---------------------------------------------------------------------------

class TopBasicLayer(nn.Module):
    """
    Lightweight transformer block for High-GD global token generation.
    Uses depthwise separable conv to approximate attention cheaply.

    Args:
        embed_dim     : input/output channels
        trans_channels: list [ch0, ch1] — output split sizes

    YAML usage:  [-1, 1, TopBasicLayer, [352, [64, 128]]]
    """
    def __init__(self, embed_dim, trans_channels):
        super().__init__()
        self.norm1 = nn.BatchNorm2d(embed_dim)
        self.dw    = nn.Conv2d(embed_dim, embed_dim, 3, 1, 1, groups=embed_dim, bias=False)
        self.norm2 = nn.BatchNorm2d(embed_dim)
        self.pw1   = nn.Conv2d(embed_dim, embed_dim * 2, 1, bias=False)
        self.act   = nn.SiLU()
        self.pw2   = nn.Conv2d(embed_dim * 2, embed_dim, 1, bias=False)

        out_c = sum(trans_channels)
        self.proj = nn.Conv2d(embed_dim, out_c, 1, bias=False)
        self.trans_channels = trans_channels

    def forward(self, x):
        x = x + self.dw(self.norm1(x))
        x = x + self.pw2(self.act(self.pw1(self.norm2(x))))
        x = self.proj(x)
        return x.split(self.trans_channels, dim=1)   # tuple


# ---------------------------------------------------------------------------
# AdvPoolFusion  — High-GD local feature aggregation
# ---------------------------------------------------------------------------

class AdvPoolFusion(nn.Module):
    """
    Fuse two adjacent feature maps: upsample the smaller to the larger,
    then concatenate. Used before InjectionMultiSum_Auto_pool in High-GD.

    YAML usage:  [[20, 17], 1, AdvPoolFusion, []]
    Takes a list of exactly 2 tensors.
    """
    def forward(self, xs):
        x0, x1 = xs
        if x0.shape[2:] != x1.shape[2:]:
            # upsample the smaller one
            if x0.shape[2] < x1.shape[2]:
                x0 = F.interpolate(x0, size=x1.shape[2:], mode='bilinear', align_corners=False)
            else:
                x1 = F.interpolate(x1, size=x0.shape[2:], mode='bilinear', align_corners=False)
        return torch.cat([x0, x1], dim=1)
    
# MTD-YOLO modules
# Source: Zhang et al., "MTD-YOLO: An Improved YOLOv8-Based Rice Pest
#         Detection Model", Electronics 2025, 14(14):2912
#         https://doi.org/10.3390/electronics14142912
#
# Two modules:
#   MBConv  — MobileNetV3 inverted-residual "bneck" block (backbone)
#   C2f_T   — C2f with Triplet Attention in each bottleneck (neck/head)
#             (reuses the existing AttentionGate / TripletAttention from other reference)


def _make_divisible(v, divisor=8, min_value=None):
    """Round channel counts to nearest multiple of divisor (MobileNetV3 rule)."""
    if min_value is None:
        min_value = divisor
    new_v = max(min_value, int(v + divisor / 2) // divisor * divisor)
    if new_v < 0.9 * v:
        new_v += divisor
    return new_v


class _HSigmoid(nn.Module):
    def forward(self, x):
        return F.relu6(x + 3.0, inplace=True) / 6.0


class _HSwish(nn.Module):
    def forward(self, x):
        return x * (F.relu6(x + 3.0, inplace=True) / 6.0)


class _SqueezeExcite(nn.Module):
    """SE block used inside MobileNetV3 bneck."""

    def __init__(self, channels: int, reduction: int = 4):
        super().__init__()
        mid = _make_divisible(channels // reduction)
        self.fc1 = nn.Conv2d(channels, mid, 1)
        self.fc2 = nn.Conv2d(mid, channels, 1)
        self.act = nn.ReLU(inplace=True)
        self.gate = _HSigmoid()
        channels = 24

    def forward(self, x):
        s = F.adaptive_avg_pool2d(x, 1)
        s = self.act(self.fc1(s))
        s = self.gate(self.fc2(s))
        return x * s


class MBConv(nn.Module):
    """
    MobileNetV3 inverted-residual block ("bneck").
    expand 1x1 -> depthwise kxk (stride s) -> [SE] -> project 1x1 (+residual)

    YAML args (positional, matches C3k2-style: c1 auto from ch[f]):
        [c2, k, s, expand_ratio, use_se, use_hs]
    Defaults: k=3, s=1, expand_ratio=4, use_se=True, use_hs=True

    Example:
        - [-1, 1, MBConv, [16, 3, 2, 1, False, False]]   # stage 1, no expand, ReLU, SE off
        - [-1, 1, MBConv, [24, 3, 2, 4, False, False]]   # stage 2
        - [-1, 1, MBConv, [40, 5, 2, 3, True,  True ]]   # stage 3, SE+HSwish
    """

    def __init__(
        self,
        c1: int,
        c2: int,
        k: int = 3,
        s: int = 1,
        expand_ratio: float = 4,
        use_se: bool = True,
        use_hs: bool = True,
    ):
        super().__init__()
        c_mid = _make_divisible(c1 * expand_ratio)
        act = _HSwish() if use_hs else nn.ReLU(inplace=True)
        self.add = (s == 1 and c1 == c2)

        layers = []
        # expand (skip if expand_ratio==1, i.e. c_mid == c1)
        if c_mid != c1:
            layers += [
                nn.Conv2d(c1, c_mid, 1, bias=False),
                nn.BatchNorm2d(c_mid),
                act,
            ]
        # depthwise
        layers += [
            nn.Conv2d(c_mid, c_mid, k, s, k // 2, groups=c_mid, bias=False),
            nn.BatchNorm2d(c_mid),
        ]
        self.dw_act = act
        self.pre_se = nn.Sequential(*layers)
        self.se = _SqueezeExcite(c_mid) if use_se else nn.Identity()
        # project
        self.project = nn.Sequential(
            nn.Conv2d(c_mid, c2, 1, bias=False),
            nn.BatchNorm2d(c2),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.dw_act(self.pre_se(x))
        y = self.se(y)
        y = self.project(y)
        return x + y if self.add else y


# C2f_T : C2f with Triplet Attention

class _TBottleneck(nn.Module):
    """Standard C2f bottleneck with TripletAttention appended."""

    def __init__(self, c1, c2, shortcut=True, g=1, k=(3, 3), e=0.5):
        super().__init__()
        c_ = int(c2 * e)
        self.cv1 = Conv(c1, c_, k[0], 1)
        self.cv2 = Conv(c_, c2, k[1], 1, g=g)
        self.attn = TripletAttention(c2)   # reused, unchanged
        self.add = shortcut and c1 == c2

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.attn(self.cv2(self.cv1(x)))
        return x + y if self.add else y


class C2f_T(nn.Module):
    """
    C2f + Triplet Attention ("C2f-T" in the MTD-YOLO paper).
    Same split/concat skeleton as Ultralytics C2f; each bottleneck ends
    with TripletAttention for channel-spatial dual-attention.

    YAML usage (identical positional args to C2f / C3k2):
        - [-1, 2, C2f_T, [512, True]]
    """

    def __init__(self, c1: int, c2: int, n: int = 1, shortcut: bool = False,
                 g: int = 1, e: float = 0.5):
        super().__init__()
        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1)
        self.m = nn.ModuleList(
            _TBottleneck(self.c, self.c, shortcut, g, k=(3, 3), e=1.0)
            for _ in range(n)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = list(self.cv1(x).chunk(2, 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))
    
class C3k2BRA(C2f):
    """
    C3k2 variant with Bi-Level Routing Attention inside each bottleneck.

    Inherits C2f so channel arithmetic, forward(), and YAML parsing all
    work identically to C3k2 — parse_model needs zero extra handling.

    YAML usage (same positional args as C3k2):
        # [from, repeats, module,   [c2,  shortcut, e  ]]
        - [-1,   2,       C3k2BRA, [512, False,    0.5]]

    You can also pass BRA-specific kwargs after e if you want to tune:
        - [-1, 2, C3k2BRA, [512, False, 0.5, 7, 4, 4]]
                                              ↑    ↑  ↑
                                           n_win  heads topk
    """

    def __init__(
        self,
        c1: int,
        c2: int,
        n: int = 1,
        shortcut: bool = False,
        g: int = 1,       # unused — kept so YAML arg positions match C3k2
        e: float = 0.5,
        n_win: int = 7,
        num_heads: int = 4,
        topk: int = 4,
        side_dwconv: int = 3,
    ):
        super().__init__(c1, c2, n, shortcut, g, e)  # sets self.c, cv1, cv2
        # Override the bottleneck list with BRA-bottlenecks
        self.m = nn.ModuleList(
            _BRABottleneck(
                self.c, self.c,
                shortcut=shortcut,
                n_win=n_win,
                num_heads=min(num_heads, self.c // 32),  # guard: heads ≤ c/32
                topk=topk,
                side_dwconv=side_dwconv,
            )
            for _ in range(n)
        )


class _BRABottleneck(nn.Module):
    """Single bottleneck: Conv-BN-SiLU → BRA → Conv-BN-SiLU (+ residual)."""

    def __init__(
        self,
        c1: int,
        c2: int,
        shortcut: bool = True,
        n_win: int = 7,
        num_heads: int = 4,
        topk: int = 4,
        side_dwconv: int = 3,
    ):
        super().__init__()
        self.cv1  = Conv(c1, c2, 1)   # uses the Conv already imported in block.py
        self.attn = BiLevelRoutingAttention(
            dim=c2,
            num_heads=max(1, num_heads),
            n_win=n_win,
            topk=topk,
            side_dwconv=side_dwconv,
            auto_pad=True,
        )
        self.cv2  = Conv(c2, c2, 1)
        self.add  = shortcut and c1 == c2

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.cv2(self.attn(self.cv1(x)))
        return x + y if self.add else y

class EMA(nn.Module):
    """
    Efficient Multi-Scale Attention (EMA) module — ICASSP 2023.

    Splits channels into G groups (reshaped into the batch dim so all ops
    are standard 2-D convolutions — no custom ops, fully DDP-safe), then
    runs two parallel branches and fuses them with cross-spatial matmul.

    Args:
        channels (int): Number of input channels.  Must be divisible by factor.
        factor   (int): Number of channel groups G.  Paper default = 32.
    """

    def __init__(self, channels: int, factor: int = 32):
        super().__init__()

        assert channels % factor == 0, (
            f"EMA: channels ({channels}) must be divisible by factor ({factor}). "
            f"Try factor=16 or adjust your channel count."
        )

        self.groups = factor
        c_per_group = channels // factor   # c//g in the paper

        # ── 1×1 branch ────────────────────────────────────────────────────
        # Pool along H → shape (b*g, c//g, h, 1)
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        # Pool along W → shape (b*g, c//g, 1, w)
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))
        # Shared 1×1 conv on concatenated [pool_h ; pool_w] — no dim reduction
        self.conv1x1 = nn.Conv2d(c_per_group, c_per_group,
                                 kernel_size=1, bias=False)
        # GroupNorm: 1 group over c//g channels (= LayerNorm over channels)
        # This is rank-independent — safe for DDP across any world_size.
        self.gn = nn.GroupNorm(num_groups=1, num_channels=c_per_group,
                               affine=True)

        # ── 3×3 branch ────────────────────────────────────────────────────
        self.conv3x3 = nn.Conv2d(c_per_group, c_per_group,
                                 kernel_size=3, padding=1, bias=False)

        # ── Cross-spatial learning ─────────────────────────────────────────
        # 2-D global avg pool to compress spatial → (b*g, c//g, 1, 1)
        self.agp = nn.AdaptiveAvgPool2d((1, 1))
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x : (B, C, H, W)
        Returns:
            (B, C, H, W)  — same shape, re-weighted by cross-spatial attention
        """
        B, C, H, W = x.shape
        G = self.groups
        cg = C // G          # channels per group

        # ── Feature grouping: reshape G groups into batch dim ──────────────
        # (B, C, H, W) → (B*G, C//G, H, W)
        xg = x.reshape(B * G, cg, H, W)

        # ══ 1×1 BRANCH ════════════════════════════════════════════════════
        # Horizontal pool: (B*G, cg, H, 1)
        x_h = self.pool_h(xg)
        # Vertical pool + transpose to match height dim for concat:
        # pool_w → (B*G, cg, 1, W) → permute → (B*G, cg, W, 1)
        x_w = self.pool_w(xg).permute(0, 1, 3, 2)

        # Concat along height dim → (B*G, cg, H+W, 1), shared 1×1 conv
        hw = self.conv1x1(torch.cat([x_h, x_w], dim=2))

        # Split back into h-part and w-part
        x_h, x_w = torch.split(hw, [H, W], dim=2)

        # Re-weight group features:
        #   x_h.sigmoid(): (B*G, cg, H, 1)
        #   x_w.permute(0,1,3,2).sigmoid(): (B*G, cg, 1, W)
        # broadcast-multiply with xg → (B*G, cg, H, W)
        x1 = self.gn(xg * x_h.sigmoid() * x_w.permute(0, 1, 3, 2).sigmoid())

        # ══ 3×3 BRANCH ════════════════════════════════════════════════════
        x2 = self.conv3x3(xg)   # (B*G, cg, H, W)

        # ══ CROSS-SPATIAL LEARNING ════════════════════════════════════════
        # --- First matmul: global-pool(x1) × flatten(x2) ---
        # agp(x1) → (B*G, cg, 1, 1) → reshape → (B*G, 1, cg)  [row vector]
        x11 = self.softmax(
            self.agp(x1).reshape(B * G, 1, cg)
        )
        # x2 flatten spatial → (B*G, cg, H*W)
        x12 = x2.reshape(B * G, cg, H * W)
        # matmul: (B*G, 1, cg) × (B*G, cg, H*W) → (B*G, 1, H*W)

        # --- Second matmul: global-pool(x2) × flatten(x1) ---
        x21 = self.softmax(
            self.agp(x2).reshape(B * G, 1, cg)
        )
        x22 = x1.reshape(B * G, cg, H * W)
        # matmul: (B*G, 1, cg) × (B*G, cg, H*W) → (B*G, 1, H*W)

        # Sum both attention maps → (B*G, 1, H, W)
        weights = (
            torch.bmm(x11, x12) + torch.bmm(x21, x22)
        ).reshape(B * G, 1, H, W)

        # ── Final gating and reshape back ─────────────────────────────────
        # (B*G, cg, H, W) * sigmoid(B*G, 1, H, W) → broadcast over channels
        out = (xg * weights.sigmoid()).reshape(B, C, H, W)
        return out

class LSKA(nn.Module):
    """
    Large Separable Kernel Attention module.

    Reference: https://github.com/StevenLauHKHK/Large-Separable-Kernel-Attention
    Decomposes large-kernel depthwise attention into cascaded 1D horizontal/vertical convs.
    Acts as a spatial attention gate: input * attention_map.

    Args:
        dim (int): number of input/output channels.
        k_size (int): effective large kernel size. One of [7, 11, 23, 35, 41, 53].
    """

    def __init__(self, dim, k_size=23):
        super().__init__()
        self.k_size = k_size

        if k_size == 7:
            self.DW_conv_h = nn.Conv2d(dim, dim, (1, 3), padding=(0, 1), groups=dim)
            self.DW_conv_v = nn.Conv2d(dim, dim, (3, 1), padding=(1, 0), groups=dim)
            self.DW_D_conv_h = nn.Conv2d(dim, dim, (1, 3), padding=(0, 2), groups=dim, dilation=2)
            self.DW_D_conv_v = nn.Conv2d(dim, dim, (3, 1), padding=(2, 0), groups=dim, dilation=2)
        elif k_size == 11:
            self.DW_conv_h = nn.Conv2d(dim, dim, (1, 3), padding=(0, 1), groups=dim)
            self.DW_conv_v = nn.Conv2d(dim, dim, (3, 1), padding=(1, 0), groups=dim)
            self.DW_D_conv_h = nn.Conv2d(dim, dim, (1, 5), padding=(0, 4), groups=dim, dilation=2)
            self.DW_D_conv_v = nn.Conv2d(dim, dim, (5, 1), padding=(4, 0), groups=dim, dilation=2)
        elif k_size == 23:
            self.DW_conv_h = nn.Conv2d(dim, dim, (1, 5), padding=(0, 2), groups=dim)
            self.DW_conv_v = nn.Conv2d(dim, dim, (5, 1), padding=(2, 0), groups=dim)
            self.DW_D_conv_h = nn.Conv2d(dim, dim, (1, 7), padding=(0, 9), groups=dim, dilation=3)
            self.DW_D_conv_v = nn.Conv2d(dim, dim, (7, 1), padding=(9, 0), groups=dim, dilation=3)
        elif k_size == 35:
            self.DW_conv_h = nn.Conv2d(dim, dim, (1, 5), padding=(0, 2), groups=dim)
            self.DW_conv_v = nn.Conv2d(dim, dim, (5, 1), padding=(2, 0), groups=dim)
            self.DW_D_conv_h = nn.Conv2d(dim, dim, (1, 11), padding=(0, 15), groups=dim, dilation=3)
            self.DW_D_conv_v = nn.Conv2d(dim, dim, (11, 1), padding=(15, 0), groups=dim, dilation=3)
        elif k_size == 41:
            self.DW_conv_h = nn.Conv2d(dim, dim, (1, 5), padding=(0, 2), groups=dim)
            self.DW_conv_v = nn.Conv2d(dim, dim, (5, 1), padding=(2, 0), groups=dim)
            self.DW_D_conv_h = nn.Conv2d(dim, dim, (1, 13), padding=(0, 18), groups=dim, dilation=3)
            self.DW_D_conv_v = nn.Conv2d(dim, dim, (13, 1), padding=(18, 0), groups=dim, dilation=3)
        elif k_size == 53:
            self.DW_conv_h = nn.Conv2d(dim, dim, (1, 5), padding=(0, 2), groups=dim)
            self.DW_conv_v = nn.Conv2d(dim, dim, (5, 1), padding=(2, 0), groups=dim)
            self.DW_D_conv_h = nn.Conv2d(dim, dim, (1, 17), padding=(0, 24), groups=dim, dilation=3)
            self.DW_D_conv_v = nn.Conv2d(dim, dim, (17, 1), padding=(24, 0), groups=dim, dilation=3)
        else:
            raise ValueError(f"k_size must be one of [7, 11, 23, 35, 41, 53], got {k_size}")

        self.conv1 = nn.Conv2d(dim, dim, 1)

    def forward(self, x):
        u = x.clone()
        attn = self.DW_conv_h(x)
        attn = self.DW_conv_v(attn)
        attn = self.DW_D_conv_h(attn)
        attn = self.DW_D_conv_v(attn)
        attn = self.conv1(attn)
        return u * attn